#include <iostream>
#include <fstream>
#include <sstream>

#include <string>
#include <vector>
#include <cstdlib>

#include <dirent.h>

using namespace std;


vector <string> getFileList (string Path)
{
    vector <string> List;
    
    DIR *info;
    struct dirent *dir;
    
    //Specify the directory name
    info = opendir (Path.c_str ());
    
    if (info)
    {
        while ((dir = readdir (info)) != NULL)
        {
            string filename = dir->d_name;
            
            size_t filename_end = filename.rfind (".csv");
            if (filename_end != std::string::npos)
            {
                filename_end += 4;
                
                if (filename_end == filename.length ())
                {
                    List.push_back (filename);
                }
            }
        }
        
        closedir (info);
    }
    
    return List;
}


std::ifstream::pos_type getFileSize(const char* Filename)
{
    std::ifstream in (Filename, std::ifstream::ate | std::ifstream::binary);
    return in.tellg(); 
}


vector <string> parseLine (string Line)
{
    vector <string> Array;
    
    int Size = Line.length ();
    
    int Ignore_all = false;
    int Quotes = false;
    
    for (int i = 0, Start = 0; i < Size; i++)
    {
        switch (Line [i])
        {
            case '\"':
                !Ignore_all;
                Quotes = true;
                
                break;
            case ',':
                if (!Ignore_all)
                {
                    //Take item
                    if (Quotes)
                    {
                        Array.push_back (Line.substr (Start + 1, i - Start - 2));
                        Quotes = false;
                    }
                    else
                        Array.push_back (Line.substr (Start, i - Start));
                    
                    Start = i + 1;
                }
                break;
        }
    }
    
    return Array;
}


vector < vector<string> > createGrid ()
{
    vector < vector<string> > Arr;
    vector<string> Head;
    
    Head.push_back ("Name");
    Head.push_back ("Copy Full Color - Small");
    Head.push_back ("Copy Full Color - Large");
    Head.push_back ("Copy Twin Color - Small");
    Head.push_back ("Copy Twin Color - Large");
    Head.push_back ("Copy Black - Small");
    Head.push_back ("Copy Black - Large");
    
    Head.push_back ("Printer Full Color - Small");
    Head.push_back ("Printer Full Color - Large");
    Head.push_back ("Printer Twin Color - Small");
    Head.push_back ("Printer Twin Color - Large");
    Head.push_back ("Printer Black - Small");
    Head.push_back ("Printer Black - Large");
    
    Head.push_back ("Scanner Full Color - Small");
    Head.push_back ("Scanner Full Color - Large");
    Head.push_back ("Scanner Black - Small");
    Head.push_back ("Scanner Black - Large");
    
    Arr.push_back (Head);
    return Arr;
}


vector<string> createUser (string User)
{
    vector<string> Row;
    
    Row.push_back (User);
    
    for (int i = 0; i < 16; i++)
        Row.push_back ("0");
    
    return Row;
}


void upperString (string *s)
{
    char *string = (char*)s->c_str ();
    int c = 0, i = 0;
    
    do
    {
        c = string [i];
        string [i] = toupper (c);
        i++;
    } while (c);
    
}


int findUser (vector < vector<string> >& Grid, string& User)
{
    int r = -1;

    for (int i = 1; i < Grid.size (); i++)
    {
        //Find the match name
        if (Grid [i][0] == User)
        {
            r = i;
            break;
        }
    }

    return r;
}


int main ()
{
    
    vector < vector<string> > Grid = createGrid ();
    
    // Get file list on root folder
    vector <string> List_Files = getFileList (".");
    ifstream CurrentFile;
    
    for (int index = 0; index < List_Files.size (); index++)
    {
        const char *Filename = List_Files [index].c_str ();
        cout << "Processing... \"" << Filename << "\"\n";
        
        CurrentFile.open (Filename);
        
        string CurrentLine;
//vector <string> tmpLine;
        
        //First line - Head
        {
            getline (CurrentFile, CurrentLine);
            vector <string> Array_Line = parseLine (CurrentLine);
//tmpLine = Array_Line;
            
            //Select format type
            if (Array_Line [0] == "Number" && Array_Line.size () == 492)
            {
                //Large columns - English

                while (getline (CurrentFile, CurrentLine))
                {
                    Array_Line = parseLine (CurrentLine);

                    //Find user in grid
                    upperString (&Array_Line [1]);
                    int UPos = findUser (Grid, Array_Line [1]);
                    if (UPos == -1)
                    {
                        Grid.push_back (createUser (Array_Line [1]));
                        UPos = Grid.size () - 1;
                    }
                    
                    //Add value data corresponding to the user
                        //Copy Full Color - Small
                        {
                            int n = atoi (Grid [UPos][1].c_str ()) + 
                                    atoi (Array_Line [23].c_str ()) +       //Full Color Copier LT
                                    atoi (Array_Line [416].c_str ()) +      //Eco Copy FullColor Single Small
                                    2*atoi (Array_Line [406].c_str ());     //Eco Copy FullColor Duplex Small
                            
                            //Grid [UPos][1] = n;
                            itoa (n, (char*)Grid [UPos][1].c_str (), 10);
                        }
                        
                        //Copy Full Color - Large
                        {
                            int n = atoi (Grid [UPos][2].c_str ());
                            
                            //Grid [UPos][2] = n;
                            itoa (n, (char*)Grid [UPos][2].c_str (), 10);
                        }
                        
                        //Copy Twin Color - Small
                        {
                            int n = atoi (Grid [UPos][3].c_str ());
                            
                            //Grid [UPos][3] = n;
                            itoa (n, (char*)Grid [UPos][3].c_str (), 10);
                        }
                        
                        //Copy Twin Color - Large
                        {
                            int n = atoi (Grid [UPos][4].c_str ());
                            
                            //Grid [UPos][4] = n;
                            itoa (n, (char*)Grid [UPos][4].c_str (), 10);
                        }
                        
                        //Copy Black - Small
                        {
                            int n = atoi (Grid [UPos][5].c_str ()) + 
                                    atoi (Array_Line [197].c_str ()) +      //Black Copier LT
                                    atoi (Array_Line [440].c_str ()) +      //Eco Copy Black Single Small
                                    2*atoi (Array_Line [430].c_str ());     //Eco Copy Black Duplex Small
                            
                            //Grid [UPos][5] = n;
                            itoa (n, (char*)Grid [UPos][5].c_str (), 10);
                        }
                        
                        //Copy Black - Large
                        {
                            int n = atoi (Grid [UPos][6].c_str ());
                            
                            //Grid [UPos][6] = n;
                            itoa (n, (char*)Grid [UPos][6].c_str (), 10);
                        }
                        
                        //Printer Full Color - Small
                        {
                            int n = atoi (Grid [UPos][7].c_str ()) +        
                                    atoi (Array_Line [48].c_str ()) +       //Full Color Printer LT
                                    2*atoi (Array_Line [442].c_str ()) +    //Eco Printer FullColorPrint Duplex Small
                                    atoi (Array_Line [456].c_str ());       //Eco Printer FullColorPrint Single Small
                            
                            //Grid [UPos][7] = n;
                            itoa (n, (char*)Grid [UPos][7].c_str (), 10);
                        }
                        
                        //Printer Full Color - Large
                        {
                            int n = atoi (Grid [UPos][8].c_str ());
                            
                            //Grid [UPos][8] = n;
                            itoa (n, (char*)Grid [UPos][8].c_str (), 10);
                        }
                        
                        //Printer Twin Color - Small
                        {
                            int n = atoi (Grid [UPos][9].c_str ());
                            
                            //Grid [UPos][9] = n;
                            itoa (n, (char*)Grid [UPos][9].c_str (), 10);
                        }
                        
                        //Printer Twin Color - Large
                        {
                            int n = atoi (Grid [UPos][10].c_str ());
                            
                            //Grid [UPos][10] = n;
                            itoa (n, (char*)Grid [UPos][10].c_str (), 10);
                        }
                        
                        //Printer Black - Small
                        {
                            int n = atoi (Grid [UPos][11].c_str ()) +        
                                    atoi (Array_Line [294].c_str ()) +      //Black Printer LT
                                    2*atoi (Array_Line [474].c_str ()) +    //Eco Printer BlackPrint Duplex Small
                                    atoi (Array_Line [488].c_str ());       //Eco Printer BlackPrint Single Small

                            //Grid [UPos][11] = n;
                            itoa (n, (char*)Grid [UPos][11].c_str (), 10);
                        }
                        
                        //Printer Black - Large
                        {
                            int n = atoi (Grid [UPos][12].c_str ());
                            
                            //Grid [UPos][12] = n;
                            itoa (n, (char*)Grid [UPos][12].c_str (), 10);
                        }
                        
                        //Scanner Full Color - Small
                        {
                            int n = atoi (Grid [UPos][13].c_str ()) +        
                                    atoi (Array_Line [73].c_str ()) +       //Full Color Copier Scan LT
                                    atoi (Array_Line [96].c_str ()) +       //Full Color Network Scan LD
                                    atoi (Array_Line [98].c_str ()) +       //Full Color Network Scan LT
                                    atoi (Array_Line [99].c_str ()) +       //Full Color Network Scan ST
                                    atoi (Array_Line [100].c_str ()) +      //Full Color Network Scan COMP
                                    atoi (Array_Line [102].c_str ());       //Full Color Network Scan 85SQ
                                    
                            //Grid [UPos][13] = n;
                            itoa (n, (char*)Grid [UPos][13].c_str (), 10);
                        }
                        
                        //Scanner Full Color - Large
                        {
                            int n = atoi (Grid [UPos][14].c_str ());
                            
                            //Grid [UPos][14] = n;
                            itoa (n, (char*)Grid [UPos][14].c_str (), 10);
                        }
                        
                        //Scanner Black - Small
                        {
                            int n = atoi (Grid [UPos][15].c_str ()) +        
                                    atoi (Array_Line [343].c_str ()) +      //Black Copier Scan LT
                                    atoi (Array_Line [390].c_str ()) +      //Black Network Scan LD
                                    atoi (Array_Line [391].c_str ()) +      //Black Network Scan LG
                                    atoi (Array_Line [392].c_str ()) +      //Black Network Scan LT
                                    atoi (Array_Line [393].c_str ()) +      //Black Network Scan ST
                                    atoi (Array_Line [394].c_str ());       //Black Network Scan COMP
                                    
                            //Grid [UPos][15] = n;
                            itoa (n, (char*)Grid [UPos][15].c_str (), 10);
                        }
                        
                        //Scanner Black - Large
                        {
                            int n = atoi (Grid [UPos][16].c_str ());
                            
                            //Grid [UPos][16] = n;
                            itoa (n, (char*)Grid [UPos][16].c_str (), 10);
                        }
                        
                        
                        
                        
                }
            }
            else
            if (Array_Line [0] == "Nombre de Usuario" && Array_Line.size () == 60)
            {
                //Short columns - Spanish
                
                while (getline (CurrentFile, CurrentLine))
                {
                    Array_Line = parseLine (CurrentLine);

                    //Find user in grid
                    upperString (&Array_Line [0]);
                    int UPos = findUser (Grid, Array_Line [0]);
                    if (UPos == -1)
                    {
                        Grid.push_back (createUser (Array_Line [0]));
                        UPos = Grid.size () - 1;
                    }
                    
                    //Add value data corresponding to the user
                        //Copy Full Color - Small
                        {
                            int n = atoi (Grid [UPos][1].c_str ()) + 
                                    atoi (Array_Line [4].c_str ());         //Copia:Todo Color:P�ginas usadas
                            
                            //Grid [UPos][1] = n;
                            itoa (n, (char*)Grid [UPos][1].c_str (), 10);
                        }
                        
                        //Copy Full Color - Large
                        {
                            int n = atoi (Grid [UPos][2].c_str ());
                            
                            //Grid [UPos][2] = n;
                            itoa (n, (char*)Grid [UPos][2].c_str (), 10);
                        }
                        
                        //Copy Twin Color - Small
                        {
                            int n = atoi (Grid [UPos][3].c_str ()) + 
                                    atoi (Array_Line [7].c_str ());         //Copia:2 Colores:P�ginas usadas
                            
                            //Grid [UPos][3] = n;
                            itoa (n, (char*)Grid [UPos][3].c_str (), 10);
                        }
                        
                        //Copy Twin Color - Large
                        {
                            int n = atoi (Grid [UPos][4].c_str ());
                            
                            //Grid [UPos][4] = n;
                            itoa (n, (char*)Grid [UPos][4].c_str (), 10);
                        }
                        
                        //Copy Black - Small
                        {
                            int n = atoi (Grid [UPos][5].c_str ()) + 
                                    atoi (Array_Line [1].c_str ()) +        //Copia:Blanco y negro:P�ginas usadas
                                    atoi (Array_Line [10].c_str ());        //Copia:Un Solo Color:P�ginas usadas
                            
                            //Grid [UPos][5] = n;
                            itoa (n, (char*)Grid [UPos][5].c_str (), 10);
                        }
                        
                        //Copy Black - Large
                        {
                            int n = atoi (Grid [UPos][6].c_str ());
                            
                            //Grid [UPos][6] = n;
                            itoa (n, (char*)Grid [UPos][6].c_str (), 10);
                        }
                        
                        //Printer Full Color - Small
                        {
                            int n = atoi (Grid [UPos][7].c_str ()) +        
                                    atoi (Array_Line [16].c_str ());        //Impresora:Todo Color:P�ginas usadas
                            
                            //Grid [UPos][7] = n;
                            itoa (n, (char*)Grid [UPos][7].c_str (), 10);
                        }
                        
                        //Printer Full Color - Large
                        {
                            int n = atoi (Grid [UPos][8].c_str ());
                            
                            //Grid [UPos][8] = n;
                            itoa (n, (char*)Grid [UPos][8].c_str (), 10);
                        }
                        
                        //Printer Twin Color - Small
                        {
                            int n = atoi (Grid [UPos][9].c_str ());
                            
                            //Grid [UPos][9] = n;
                            itoa (n, (char*)Grid [UPos][9].c_str (), 10);
                        }
                        
                        //Printer Twin Color - Large
                        {
                            int n = atoi (Grid [UPos][10].c_str ());
                            
                            //Grid [UPos][10] = n;
                            itoa (n, (char*)Grid [UPos][10].c_str (), 10);
                        }
                        
                        //Printer Black - Small
                        {
                            int n = atoi (Grid [UPos][11].c_str ()) +        
                                    atoi (Array_Line [13].c_str ());       //Impresora:Blanco y negro:P�ginas usadas

                            //Grid [UPos][11] = n;
                            itoa (n, (char*)Grid [UPos][11].c_str (), 10);
                        }
                        
                        
                        //Printer Black - Large
                        {
                            int n = atoi (Grid [UPos][12].c_str ());
                            
                            //Grid [UPos][12] = n;
                            itoa (n, (char*)Grid [UPos][12].c_str (), 10);
                        }
                        
                        //Scanner Full Color - Small
                        {
                            int n = atoi (Grid [UPos][13].c_str ()) +        
                                    atoi (Array_Line [40].c_str ()) +       //Digitalizar:Todo Color:P�ginas usadas
                                    atoi (Array_Line [55].c_str ());        //Escanear a disco duro:Todo Color:P�ginas usadas
                                    
                            //Grid [UPos][13] = n;
                            itoa (n, (char*)Grid [UPos][13].c_str (), 10);
                        }
                        
                        //Scanner Full Color - Large
                        {
                            int n = atoi (Grid [UPos][14].c_str ());
                            
                            //Grid [UPos][14] = n;
                            itoa (n, (char*)Grid [UPos][14].c_str (), 10);
                        }
                        
                        //Scanner Black - Small
                        {
                            int n = atoi (Grid [UPos][15].c_str ()) +        
                                    atoi (Array_Line [37].c_str ()) +       //37 - Digitalizar:Blanco y negro:P�ginas usadas
                                    atoi (Array_Line [58].c_str ()) +       //58 - Escanear a disco duro:2 Colores:P�ginas usadas
                                    atoi (Array_Line [52].c_str ());        //52 - Escanear a disco duro:Blanco y negro:P�ginas usadas
                                    
                            //Grid [UPos][15] = n;
                            itoa (n, (char*)Grid [UPos][15].c_str (), 10);
                        }
                        
                        //Scanner Black - Large
                        {
                            int n = atoi (Grid [UPos][16].c_str ());
                            
                            //Grid [UPos][16] = n;
                            itoa (n, (char*)Grid [UPos][16].c_str (), 10);
                        }
                        
                        
                        
                        
                        
                        
                        
                }
            }
            
            
            
            
            
            
        }
        
        
        
        
//for (int i = 0; i < tmpLine.size (); i++)
//{
//    if (tmpLine [i] == "Escanear a disco duro:2 Colores:P�ginas usadas")
//        cout << "Position: " << i << endl;
//}
        
        
        
        CurrentFile.close ();
        
        
        
        
        cout << "---------------------\n";
    }


    cout << "\n\n";

    
    //for (int i = 0; i < Grid.size (); i++)
    //{
    //    cout << Grid [i][0] << endl;
    //}
    

    //cout << Grid.size ();
    
    
    ofstream Output ("Output/Consolidated Data.txt");
    
    for (int i = 0; i < Grid.size (); i++)
    {
        for (int j = 0; j < Grid [0].size (); j++)
        {
            Output << Grid [i][j] << "\t";
        }
        
        Output << endl;
    }
    
    Output.close ();
    
    
    
    cout << "End\n";
    
}




